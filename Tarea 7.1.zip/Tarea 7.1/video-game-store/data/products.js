const products = [
    {
        id: 1,
        category: "games",
        title: "God of War Ragnarök",
        price: 59.99,
        platform: "PlayStation",
        coverImage: "https://upload.wikimedia.org/wikipedia/en/e/ee/God_of_War_Ragnar%C3%B6k_cover.jpg",
        description: "Acompaña a Kratos y Atreus en una aventura épica por los Nueve Reinos."
    },
    {
        id: 2,
        category: "games",
        title: "Marvel's Spider-Man 2",
        price: 69.99,
        platform: "PlayStation",
        coverImage: "https://upload.wikimedia.org/wikipedia/en/0/0f/SpiderMan2PS5BoxArt.jpeg",
        description: "Explora Nueva York y juega como Peter Parker y Miles Morales."
    },
    {
        id: 3,
        category: "games",
        title: "Gran Turismo 7",
        price: 59.99,
        platform: "PlayStation",
        coverImage: "https://upload.wikimedia.org/wikipedia/en/1/14/Gran_Turismo_7_cover_art.jpg",
        description: "Compite con cientos de autos en una experiencia de carreras realista."
    },
    {
        id: 4,
        category: "games",
        title: "Forza Horizon 5",
        price: 59.99,
        platform: "Xbox",
        coverImage: "https://upload.wikimedia.org/wikipedia/en/8/86/Forza_Horizon_5_cover_art.jpg",
        description: "Recorre los paisajes de México en un festival de carreras de mundo abierto."
    },
    {
        id: 5,
        category: "games",
        title: "Halo Infinite",
        price: 49.99,
        platform: "Xbox",
        coverImage: "https://upload.wikimedia.org/wikipedia/en/1/14/Halo_Infinite.png",
        description: "Defiende a la humanidad en una nueva campaña del universo Halo."
    },
    {
        id: 6,
        category: "games",
        title: "Starfield",
        price: 69.99,
        platform: "Xbox",
        coverImage: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fb/Starfield_-_game_cover.png/500px-Starfield_-_game_cover.png",
        description: "Embárcate en una aventura espacial y explora cientos de planetas."
    },
    {
        id: 7,
        category: "games",
        title: "The Legend of Zelda: Tears of the Kingdom",
        price: 59.99,
        platform: "Nintendo",
        coverImage: "https://upload.wikimedia.org/wikipedia/en/f/fb/The_Legend_of_Zelda_Tears_of_the_Kingdom_cover.jpg",
        description: "Descubre los secretos de Hyrule en esta aventura para Nintendo Switch."
    },
    {
        id: 8,
        category: "games",
        title: "Super Mario Bros. Wonder",
        price: 59.99,
        platform: "Nintendo",
        coverImage: "https://mario.wiki.gallery/images/thumb/9/9e/SMBW_box_NA.png/500px-SMBW_box_NA.png",
        description: "Disfruta una nueva aventura de plataformas junto a Mario y sus amigos."
    },
    {
        id: 9,
        category: "games",
        title: "Mario Kart 8 Deluxe",
        price: 49.99,
        platform: "Nintendo",
        coverImage: "https://mario.wiki.gallery/images/thumb/c/c6/Mario_Kart_8_Deluxe_Canada_boxart.jpg/500px-Mario_Kart_8_Deluxe_Canada_boxart.jpg",
        description: "Compite en circuitos clásicos y nuevos con tus personajes favoritos."
    },
    {
        id: 10,
        category: "consoles",
        title: "PlayStation 5",
        price: 499.99,
        platform: "PlayStation",
        image: "../assets/products/playstation-5.jpg",
        description: "Consola PlayStation 5 con gráficos de nueva generación y almacenamiento SSD.",
        specs: [
            { label: "Procesador", value: "AMD Zen 2 de 8 núcleos, hasta 3.5 GHz" },
            { label: "Gráficos", value: "AMD RDNA 2, hasta 10.3 TFLOPS" },
            { label: "Memoria", value: "16 GB GDDR6" },
            { label: "Almacenamiento", value: "SSD de 1 TB" },
            { label: "Resolución", value: "Hasta 4K y 120 Hz en juegos compatibles" },
            { label: "Unidad óptica", value: "Lector Blu-ray Ultra HD" }
        ]
    },
    {
        id: 11,
        category: "consoles",
        title: "Xbox Series X",
        price: 499.99,
        platform: "Xbox",
        image: "../assets/products/xbox-series-x.jpg",
        description: "Consola Xbox Series X para jugar en 4K con tiempos de carga rápidos.",
        specs: [
            { label: "Procesador", value: "AMD Zen 2 de 8 núcleos, hasta 3.8 GHz" },
            { label: "Gráficos", value: "AMD RDNA 2, 12 TFLOPS" },
            { label: "Memoria", value: "16 GB GDDR6" },
            { label: "Almacenamiento", value: "SSD NVMe de 1 TB" },
            { label: "Resolución", value: "Hasta 4K y 120 FPS en juegos compatibles" },
            { label: "Unidad óptica", value: "Lector Blu-ray 4K UHD" }
        ]
    },
    {
        id: 12,
        category: "consoles",
        title: "Nintendo Switch OLED",
        price: 349.99,
        platform: "Nintendo",
        image: "../assets/products/nintendo-switch-oled.png",
        description: "Consola híbrida con pantalla OLED de 7 pulgadas para jugar en casa o donde quieras.",
        specs: [
            { label: "Pantalla", value: "OLED táctil de 7 pulgadas" },
            { label: "Resolución portátil", value: "1280 × 720 píxeles" },
            { label: "Almacenamiento", value: "64 GB, ampliable con tarjeta microSD" },
            { label: "Modos de juego", value: "Televisor, sobremesa y portátil" },
            { label: "Salida en televisor", value: "Hasta 1920 × 1080 a 60 FPS" },
            { label: "Batería", value: "Aproximadamente 4.5 a 9 horas, según el juego" }
        ]
    },
    {
        id: 13,
        category: "controllers",
        title: "Control inalámbrico DualSense",
        price: 69.99,
        platform: "PlayStation",
        image: "../assets/products/dualsense.jpg",
        description: "Control para PlayStation 5 con respuesta háptica y gatillos adaptativos."
    },
    {
        id: 14,
        category: "controllers",
        title: "Control inalámbrico Xbox",
        price: 59.99,
        platform: "Xbox",
        image: "../assets/products/xbox-controller.jpg",
        description: "Control Xbox con diseño ergonómico, Bluetooth y botón para compartir."
    },
    {
        id: 15,
        category: "controllers",
        title: "Par de Joy-Con",
        price: 79.99,
        platform: "Nintendo",
        image: "../assets/products/joycon.jpg",
        description: "Dos controles Joy-Con para jugar en modo portátil, sobremesa o multijugador."
    },
    {
        id: 16,
        category: "accessories",
        title: "Visor de realidad virtual PlayStation VR2",
        price: 149.99,
        platform: "PlayStation",
        image: "../assets/products/playstation-vr2.jpg",
        description: "Visor PlayStation VR2 con pantalla de alta definición y audio envolvente."
    },
    {
        id: 17,
        category: "accessories",
        title: "Audífonos inalámbricos Xbox",
        price: 109.99,
        platform: "Xbox",
        image: "../assets/products/xbox-wireless-headset.jpg",
        description: "Audífonos inalámbricos oficiales con sonido envolvente para jugar en Xbox."
    },
    {
        id: 18,
        category: "accessories",
        title: "Control Pro para Nintendo Switch",
        price: 79.99,
        platform: "Nintendo",
        image: "../assets/products/switch-pro-controller.jpg",
        description: "Control Pro oficial de Nintendo Switch con controles de movimiento y vibración HD."
    }
];

export default products;