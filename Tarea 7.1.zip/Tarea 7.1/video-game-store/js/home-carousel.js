import products from '../data/products.js';

const track = document.querySelector('[data-carousel-track]');
const indicators = document.querySelector('[data-carousel-indicators]');
const status = document.querySelector('[data-carousel-status]');
const previousButton = document.querySelector('[data-carousel-previous]');
const nextButton = document.querySelector('[data-carousel-next]');

if (!track || !indicators || !status || !previousButton || !nextButton) {
    throw new Error('No se encontró la estructura del carrusel de videojuegos.');
}

const featuredGames = [2, 1, 4, 7, 8, 6]
    .map(id => products.find(product => product.id === id))
    .filter(product => product?.category === 'games' && product.coverImage);

if (featuredGames.length === 0) {
    throw new Error('No hay videojuegos con portada para mostrar en el carrusel.');
}

let activeIndex = 0;

featuredGames.forEach((game, index) => {
    const slide = document.createElement('article');
    slide.classList.add('featured-slide');
    slide.setAttribute('role', 'group');
    slide.setAttribute('aria-roledescription', 'diapositiva');
    slide.setAttribute('aria-label', `${index + 1} de ${featuredGames.length}: ${game.title}`);

    const copy = document.createElement('div');
    const platform = document.createElement('span');
    platform.classList.add('featured-platform');
    platform.textContent = game.platform;

    const title = document.createElement('h3');
    title.textContent = game.title;

    const description = document.createElement('p');
    description.textContent = game.description;

    const link = document.createElement('a');
    link.classList.add('btn');
    link.href = 'pages/catalog.html';
    link.textContent = 'Descubrir en el catálogo';

    copy.append(platform, title, description, link);

    const art = document.createElement('div');
    art.classList.add('featured-art');

    const image = document.createElement('img');
    image.src = game.coverImage;
    image.alt = `Portada de ${game.title}`;
    image.loading = index === 0 ? 'eager' : 'lazy';
    image.decoding = 'async';
    art.appendChild(image);

    slide.append(copy, art);
    track.appendChild(slide);

    const indicator = document.createElement('button');
    indicator.classList.add('carousel-indicator');
    indicator.type = 'button';
    indicator.setAttribute('aria-label', `Mostrar ${game.title}`);
    indicator.setAttribute('aria-pressed', String(index === activeIndex));
    indicator.addEventListener('click', () => showSlide(index));
    indicators.appendChild(indicator);
});

const slides = [...track.children];
const indicatorButtons = [...indicators.children];

function showSlide(index) {
    activeIndex = (index + slides.length) % slides.length;
    track.style.transform = `translateX(-${activeIndex * 100}%)`;

    slides.forEach((slide, slideIndex) => {
        const isActive = slideIndex === activeIndex;
        slide.setAttribute('aria-hidden', String(!isActive));
        slide.inert = !isActive;
    });

    indicatorButtons.forEach((indicator, indicatorIndex) => {
        indicator.setAttribute('aria-pressed', String(indicatorIndex === activeIndex));
    });

    status.textContent = `${activeIndex + 1} de ${slides.length}: ${featuredGames[activeIndex].title}`;
}

previousButton.addEventListener('click', () => showSlide(activeIndex - 1));
nextButton.addEventListener('click', () => showSlide(activeIndex + 1));
showSlide(activeIndex);
