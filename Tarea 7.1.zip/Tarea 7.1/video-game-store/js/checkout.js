import { clearCart, getCart } from './cart-store.js';

const checkoutForm = document.getElementById('checkout-form');
const checkoutStatus = document.getElementById('checkout-status');

try {
    if (getCart().length === 0) {
        checkoutForm.hidden = true;
        checkoutStatus.textContent = 'Tu carrito está vacío. Añade juegos antes de finalizar la compra.';
    }
} catch (error) {
    console.error('No se pudo comprobar el carrito antes del pago:', error);
    checkoutForm.hidden = true;
    checkoutStatus.textContent = 'No se pudo cargar tu carrito. Vuelve a intentarlo desde la página del carrito.';
}

checkoutForm.addEventListener('submit', event => {
    event.preventDefault();

    try {
        if (getCart().length === 0) {
            checkoutForm.hidden = true;
            checkoutStatus.textContent = 'Tu carrito está vacío. Añade juegos antes de finalizar la compra.';
            return;
        }

        clearCart();
        window.location.href = 'order-confirmation.html';
    } catch (error) {
        console.error('No se pudo completar la compra:', error);
        checkoutStatus.textContent = 'No se pudo completar la compra. Inténtalo de nuevo.';
    }
});
