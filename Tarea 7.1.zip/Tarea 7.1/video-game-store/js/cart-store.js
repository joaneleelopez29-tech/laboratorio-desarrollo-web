const CART_STORAGE_KEY = 'gamestart-cart';

export function getCart() {
    const savedCart = localStorage.getItem(CART_STORAGE_KEY);
    if (!savedCart) {
        return [];
    }

    const cart = JSON.parse(savedCart);
    if (!Array.isArray(cart) || cart.some(item =>
        !Number.isInteger(item.id) ||
        typeof item.title !== 'string' ||
        !Number.isFinite(item.price) ||
        !Number.isInteger(item.quantity) ||
        item.quantity < 1
    )) {
        throw new Error('Los datos guardados del carrito no son válidos.');
    }

    return cart;
}

function saveCart(cart) {
    localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
}

export function addToCart(product) {
    const cart = getCart();
    const cartItem = cart.find(item => item.id === product.id);

    if (cartItem) {
        cartItem.quantity += 1;
    } else {
        cart.push({
            id: product.id,
            title: product.title,
            price: product.price,
            category: product.category,
            platform: product.platform,
            quantity: 1
        });
    }

    saveCart(cart);
}

export function updateCartQuantity(productId, quantity) {
    const parsedQuantity = Number(quantity);
    if (!Number.isInteger(parsedQuantity) || parsedQuantity < 1) {
        throw new Error('La cantidad debe ser un número entero mayor que cero.');
    }

    const cart = getCart();
    const cartItem = cart.find(item => item.id === productId);
    if (cartItem) {
        cartItem.quantity = parsedQuantity;
        saveCart(cart);
    }
}

export function removeFromCart(productId) {
    saveCart(getCart().filter(item => item.id !== productId));
}

export function clearCart() {
    localStorage.removeItem(CART_STORAGE_KEY);
}
