const header = document.querySelector('header');

if (!header) {
    throw new Error('No se encontró el encabezado para mostrar el botón de regreso.');
}

const backLink = document.createElement('a');
backLink.classList.add('back-link');
backLink.href = new URL('../index.html', import.meta.url).href;
backLink.setAttribute('aria-label', 'Volver a la página anterior');
backLink.title = 'Volver a la página anterior';
const arrow = document.createElement('span');
arrow.classList.add('back-link-arrow');
arrow.setAttribute('aria-hidden', 'true');
arrow.textContent = '←';

const label = document.createElement('span');
label.classList.add('back-link-label');
label.textContent = 'Volver';
backLink.append(arrow, label);

backLink.addEventListener('click', event => {
    if (!document.referrer) {
        return;
    }

    const referrer = new URL(document.referrer);
    if (referrer.origin === window.location.origin && window.history.length > 1) {
        event.preventDefault();
        window.history.back();
    }
});

header.prepend(backLink);
