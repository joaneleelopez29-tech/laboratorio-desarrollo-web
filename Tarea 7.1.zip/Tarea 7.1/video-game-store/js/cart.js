import {
    getCart,
    removeFromCart,
    updateCartQuantity
} from './cart-store.js';

const cartItemsList = document.getElementById('cart-items-list');
const cartEmptyMessage = document.getElementById('cart-empty');
const cartStatus = document.getElementById('cart-status');
const cartTable = document.querySelector('#cart-items table');
const totalPrice = document.getElementById('total-price');
const checkoutButton = document.getElementById('checkout-button');

function renderCart() {
    const cart = getCart();
    cartItemsList.replaceChildren();
    cartEmptyMessage.hidden = cart.length > 0;
    cartTable.hidden = cart.length === 0;
    checkoutButton.disabled = cart.length === 0;

    let total = 0;
    cart.forEach(item => {
        const row = document.createElement('tr');
        const titleCell = document.createElement('td');
        titleCell.textContent = item.title;

        const quantityCell = document.createElement('td');
        const quantityInput = document.createElement('input');
        quantityInput.type = 'number';
        quantityInput.min = '1';
        quantityInput.step = '1';
        quantityInput.value = String(item.quantity);
        quantityInput.setAttribute('aria-label', `Cantidad de ${item.title}`);
        quantityInput.dataset.productId = String(item.id);
        quantityCell.appendChild(quantityInput);

        const priceCell = document.createElement('td');
        priceCell.textContent = `$${item.price.toFixed(2)}`;

        const subtotal = item.price * item.quantity;
        total += subtotal;
        const subtotalCell = document.createElement('td');
        subtotalCell.textContent = `$${subtotal.toFixed(2)}`;

        const actionCell = document.createElement('td');
        const removeButton = document.createElement('button');
        removeButton.type = 'button';
        removeButton.textContent = 'Quitar';
        removeButton.dataset.action = 'remove';
        removeButton.dataset.productId = String(item.id);
        removeButton.setAttribute('aria-label', `Quitar ${item.title} del carrito`);
        actionCell.appendChild(removeButton);

        row.append(titleCell, quantityCell, priceCell, subtotalCell, actionCell);
        cartItemsList.appendChild(row);
    });

    totalPrice.textContent = total.toFixed(2);
}

cartItemsList.addEventListener('change', event => {
    if (!(event.target instanceof HTMLInputElement) || !event.target.dataset.productId) {
        return;
    }

    try {
        updateCartQuantity(Number(event.target.dataset.productId), event.target.value);
        cartStatus.textContent = '';
        renderCart();
    } catch (error) {
        console.error('No se pudo actualizar la cantidad del producto:', error);
        cartStatus.textContent = 'La cantidad debe ser un número entero mayor que cero.';
        renderCart();
    }
});

cartItemsList.addEventListener('click', event => {
    if (!(event.target instanceof HTMLButtonElement) || event.target.dataset.action !== 'remove') {
        return;
    }

    try {
        removeFromCart(Number(event.target.dataset.productId));
        cartStatus.textContent = 'Se quitó el producto del carrito.';
        renderCart();
    } catch (error) {
        console.error('No se pudo quitar el producto del carrito:', error);
        cartStatus.textContent = 'No se pudo quitar el producto. Inténtalo de nuevo.';
    }
});

checkoutButton.addEventListener('click', () => {
    window.location.href = 'checkout.html';
});

try {
    renderCart();
} catch (error) {
    console.error('No se pudo cargar el carrito:', error);
    cartStatus.textContent = 'No se pudo cargar el carrito. Recarga la página para intentarlo de nuevo.';
    checkoutButton.disabled = true;
}
