import products from '../data/products.js';
import { addToCart } from './cart-store.js';

const platformCatalogs = {
    PlayStation: document.getElementById('playstation-games'),
    Xbox: document.getElementById('xbox-games'),
    Nintendo: document.getElementById('nintendo-games')
};
const categoryCatalogs = {
    consoles: document.getElementById('consoles-products'),
    controllers: document.getElementById('controllers-products'),
    accessories: document.getElementById('accessories-products')
};
const categorySections = document.querySelectorAll('.catalog-category');
const categoryFilters = document.querySelectorAll('.catalog-nav [data-category]');
const platformSections = document.querySelectorAll('.platform-catalog');
const platformFilters = document.querySelectorAll('.catalog-nav [data-platform]');

const consoleSpecsDialog = document.createElement('dialog');
consoleSpecsDialog.classList.add('console-specs-dialog');
consoleSpecsDialog.setAttribute('aria-labelledby', 'console-specs-title');
consoleSpecsDialog.innerHTML = `
    <div class="console-specs-content">
        <button class="console-specs-close" type="button" aria-label="Cerrar especificaciones">&times;</button>
        <p class="console-specs-eyebrow">Especificaciones</p>
        <h2 id="console-specs-title"></h2>
        <dl class="console-specs-list"></dl>
    </div>
`;
document.body.appendChild(consoleSpecsDialog);

const consoleSpecsTitle = consoleSpecsDialog.querySelector('#console-specs-title');
const consoleSpecsList = consoleSpecsDialog.querySelector('.console-specs-list');
const closeSpecsButton = consoleSpecsDialog.querySelector('.console-specs-close');

closeSpecsButton.addEventListener('click', () => consoleSpecsDialog.close());
consoleSpecsDialog.addEventListener('click', event => {
    if (event.target === consoleSpecsDialog) {
        consoleSpecsDialog.close();
    }
});

categoryFilters.forEach(filter => {
    filter.addEventListener('click', () => {
        const selectedCategory = filter.dataset.category;

        categorySections.forEach(section => {
            section.hidden = section.id !== `catalog-${selectedCategory}`;
        });

        categoryFilters.forEach(categoryFilter => {
            categoryFilter.setAttribute(
                'aria-pressed',
                String(categoryFilter === filter)
            );
        });
    });
});

platformFilters.forEach(filter => {
    filter.addEventListener('click', () => {
        const selectedPlatform = filter.dataset.platform;

        platformSections.forEach(section => {
            section.hidden = selectedPlatform !== 'all' && section.id !== selectedPlatform.toLowerCase();
        });

        platformFilters.forEach(platformFilter => {
            platformFilter.setAttribute(
                'aria-pressed',
                String(platformFilter === filter)
            );
        });
    });
});

products.forEach(product => {
    const container = product.category === 'games'
        ? platformCatalogs[product.platform]
        : categoryCatalogs[product.category];
    if (!container) {
        throw new Error(`No se encontró el catálogo para ${product.category}.`);
    }

    const card = document.createElement('article');
    card.classList.add('product');
    card.dataset.platform = product.platform;
    let specsButton;

    if (product.category === 'games') {
        const showcase = document.createElement('div');
        showcase.classList.add('game-showcase');
        showcase.tabIndex = 0;
        showcase.setAttribute(
            'aria-label',
            `Portada de ${product.title}. Pasa el cursor o enfoca para ver el disco.`
        );

        const disc = document.createElement('div');
        disc.classList.add('game-disc');
        disc.setAttribute('aria-hidden', 'true');

        const discArtwork = document.createElement('img');
        discArtwork.classList.add('game-disc-artwork');
        discArtwork.src = product.coverImage;
        discArtwork.alt = '';
        discArtwork.loading = 'lazy';
        discArtwork.decoding = 'async';
        disc.appendChild(discArtwork);

        const cover = document.createElement('img');
        cover.classList.add('game-cover');
        cover.src = product.coverImage;
        cover.alt = '';
        cover.loading = 'lazy';
        cover.decoding = 'async';
        showcase.append(disc, cover);
        card.appendChild(showcase);
    } else {
        const visual = document.createElement('div');
        visual.classList.add('product-visual', `product-visual--${product.category}`);

        const image = document.createElement('img');
        image.src = product.image;
        image.alt = `Foto de ${product.title}`;
        image.loading = 'lazy';
        image.decoding = 'async';
        visual.appendChild(image);
        card.appendChild(visual);
    }

    const title = document.createElement('h4');
    title.textContent = product.title;

    const description = document.createElement('p');
    description.textContent = product.description;

    const format = document.createElement('span');
    format.classList.add('product-format');
    format.textContent = product.category === 'games'
        ? 'Juego físico'
        : product.platform;

    const price = document.createElement('p');
    price.classList.add('product-price');
    price.textContent = `$${product.price.toFixed(2)} USD`;

    if (product.category === 'consoles' && product.specs) {
        specsButton = document.createElement('button');
        specsButton.type = 'button';
        specsButton.classList.add('console-specs-button');
        specsButton.textContent = 'Ver especificaciones';
        specsButton.setAttribute('aria-haspopup', 'dialog');
        specsButton.addEventListener('click', () => {
            consoleSpecsTitle.textContent = product.title;
            consoleSpecsList.replaceChildren();

            product.specs.forEach(spec => {
                const term = document.createElement('dt');
                term.textContent = spec.label;
                const detail = document.createElement('dd');
                detail.textContent = spec.value;
                consoleSpecsList.append(term, detail);
            });

            consoleSpecsDialog.showModal();
            closeSpecsButton.focus();
        });
    }

    const addButton = document.createElement('button');
    addButton.type = 'button';
    addButton.classList.add('add-to-cart-button');
    addButton.textContent = 'Añadir al carrito';
    addButton.addEventListener('click', () => {
        const status = card.querySelector('.cart-status');
        try {
            addToCart(product);
            status.textContent = `${product.title} se añadió al carrito.`;
        } catch (error) {
            console.error('No se pudo añadir el producto al carrito:', error);
            status.textContent = 'No se pudo añadir el producto. Inténtalo de nuevo.';
        }
    });

    const status = document.createElement('p');
    status.classList.add('cart-status');
    status.setAttribute('role', 'status');
    status.setAttribute('aria-live', 'polite');

    card.append(
        title,
        description,
        format,
        price,
        ...(specsButton ? [specsButton] : []),
        addButton,
        status
    );
    container.appendChild(card);
});