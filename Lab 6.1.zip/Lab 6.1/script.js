document.addEventListener("DOMContentLoaded", () => {
  // Carrusel de imágenes
  const slides = document.querySelectorAll(".slide");
  let currentSlide = 0;

  if (slides.length > 1) {
    setInterval(() => {
      slides[currentSlide].classList.remove("active");
      currentSlide = (currentSlide + 1) % slides.length;
      slides[currentSlide].classList.add("active");
    }, 2500);
  }

  // Filtros de juegos
  const filterButtons = document.querySelectorAll(".filter-button");
  const gameShelves = document.querySelectorAll(".game-shelf");

  filterButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const filter = button.dataset.filter;

      filterButtons.forEach((btn) => btn.classList.remove("active"));
      button.classList.add("active");

      gameShelves.forEach((shelf) => {
        const category = shelf.dataset.category;
        const show = filter === "all" || filter === category;
        shelf.style.display = show ? "block" : "none";
      });
    });
  });

  // Validación del formulario
  const form = document.getElementById("contactForm");
  if (form) {
    form.addEventListener("submit", (event) => {
      event.preventDefault();

      const nameInput = form.querySelector('input[name="name"]');
      if (!nameInput.value.trim()) {
        alert("Debes escribir tu nombre.");
        return;
      }

      alert("Formulario enviado correctamente.");
      form.reset();
    });
  }
});